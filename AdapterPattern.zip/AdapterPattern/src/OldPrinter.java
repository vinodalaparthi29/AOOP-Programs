//Adaptee//

public class OldPrinter { 
	public void printOldFormat(String message) {
		System.out.println("Old Printer printing: "+message);
	}
}
