class EasyLevelFactory implements DifficultFactory {

	@Override
	public GameLevel createLevel() {
		// TODO Auto-generated method stub
		return new EasyLevel();
	}
}
