
class HardLevelFactory implements DifficultFactory{

	@Override
	public GameLevel createLevel() {
		// TODO Auto-generated method stub
		return new HardLevel();
	}
}
