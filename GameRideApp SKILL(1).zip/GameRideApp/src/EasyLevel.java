
class EasyLevel implements GameLevel {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing Easy Level");
	}
}
