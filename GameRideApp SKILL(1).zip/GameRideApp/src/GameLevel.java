
interface GameLevel {
	void play();
}
