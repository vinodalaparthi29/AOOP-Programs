
interface Vehicle {
	void ride();
}
