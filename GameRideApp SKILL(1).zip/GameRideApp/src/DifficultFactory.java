
interface DifficultFactory {
	GameLevel createLevel();
}
