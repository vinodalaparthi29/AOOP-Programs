
class Bike implements Vehicle {

	@Override
	public void ride() {
		// TODO Auto-generated method stub
		System.out.println("Riding a Bike");
	}
}
