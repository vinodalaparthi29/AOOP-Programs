
class GameLevelFactory {
	public static GameLevel getGameLevel(String difficulty) {
        if (difficulty.equalsIgnoreCase("easy")) return new EasyLevel();
        else if (difficulty.equalsIgnoreCase("hard")) return new HardLevel();
        return null;
    }
}
