
public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 GameManager game = GameManager.getInstance();
	        game.startGame();
	        GameLevel easyLevel = GameLevelFactory.getGameLevel("easy");
	        easyLevel.play();
	        
	        DifficultFactory hardFactory = new HardLevelFactory();
	        GameLevel hardLevel = hardFactory.createLevel();
	        hardLevel.play();
	        
	        // Ride Application
	        RideManager rideManager = RideManager.getInstance();
	        rideManager.requestRide("bike");
	        
	}
}
