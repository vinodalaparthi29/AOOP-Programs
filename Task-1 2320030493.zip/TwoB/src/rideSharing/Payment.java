package rideSharing;

public interface Payment {
	void pay(double amount);
}
