package rideSharing;

public abstract class PaymentFactory {
	 public abstract Payment createpayment();
	 public abstract Recipt createRecipt();
}
