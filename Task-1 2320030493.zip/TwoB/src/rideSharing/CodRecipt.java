package rideSharing;

public class CodRecipt implements Recipt{

	@Override
	public void generateRecipt() {
		System.out.println("You payment was recived by driver these is an online generated recipet");
		
	}

}
