package rideSharing;

public class Scooter implements Vehicle{

	@Override
	public void ride() {
        System.out.println("Your Scooty has been arrived please have a safe Journey :)");		
	}

}
