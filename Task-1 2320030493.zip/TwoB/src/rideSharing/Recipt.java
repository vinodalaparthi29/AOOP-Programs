package rideSharing;

public interface Recipt {
	void generateRecipt();
}
