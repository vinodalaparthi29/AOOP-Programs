package rideSharing;

public interface Vehicle {
	 void ride();
}
