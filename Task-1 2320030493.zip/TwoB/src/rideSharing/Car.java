package rideSharing;

public class Car implements Vehicle{

	@Override
	public void ride(){
		System.out.println("Your car has been arrived please have a safe Journey :)");		
	}
   
}
