package rideSharing;

public abstract class VehicleFactory {
	public abstract Vehicle createVehicle();
}
