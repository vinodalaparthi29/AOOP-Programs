package rideSharing;

public class Bike implements Vehicle{

	public void ride(){
		System.out.println("Your bike has been arrived please have a safe Journey :)");
	}

}
