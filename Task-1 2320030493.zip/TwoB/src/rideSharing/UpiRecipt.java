package rideSharing;

public class UpiRecipt implements Recipt{

	@Override
	public void generateRecipt() {
		System.out.println("You payment through upi was sucessfull these is an online generated recipet");
		
	}

}
