package gameLevel;

public class HardEnemy extends Enemy {

	@Override
	public void attack() {
		 System.out.println("Hard enemy has high damage of 25");
	}

}
