package gameLevel;

public abstract class Weapon {
	public abstract void Equip();
}
