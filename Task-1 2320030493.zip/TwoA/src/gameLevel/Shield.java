package gameLevel;

public class Shield extends Powerup{

	@Override
	public void boost() {
		System.out.println("Sheilding is being activated.");
		
	}

}
