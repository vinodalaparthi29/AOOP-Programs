package gameLevel;

public class Snipper extends Weapon{

	@Override
	public void Equip() {
		System.out.println("Equiped Snipper");		
	}

}
