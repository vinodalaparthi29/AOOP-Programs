package gameLevel;

public class EasyEnemy extends Enemy {

	
	public void attack() {
       System.out.println("Easy enemy has less damage of 5");		
	}

}
