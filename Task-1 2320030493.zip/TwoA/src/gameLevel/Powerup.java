package gameLevel;

public abstract class Powerup {
	
	public abstract void boost();
     
}
