package gameLevel;

public class Nightvision extends Powerup {

	@Override
	public void boost() {
		System.out.println("Powering Up with Night Vision");
 		
	}

}
