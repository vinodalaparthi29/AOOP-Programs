package gameLevel;

public class MediumEnemy extends Enemy{

	@Override
	public void attack() {
		 System.out.println("Medium enemy has  damage of 15");
	}

}
