package gameLevel;

public class HealthPotion extends Powerup {

	@Override
	public void boost() {
       System.out.println("Using Health Vision Health being restored");		
	}

}
