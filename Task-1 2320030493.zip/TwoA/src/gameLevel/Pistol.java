package gameLevel;

public class Pistol extends Weapon{

	@Override
	public void Equip() {
        System.out.println("Equiped Pistol");		
	}

}
