package gameLevel;

public class Shotgun extends Weapon{

	@Override
	public void Equip() {
		System.out.println("Equiped Shotgun");		
	}

}
