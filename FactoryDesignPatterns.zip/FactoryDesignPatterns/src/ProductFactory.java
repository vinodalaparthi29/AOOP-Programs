public class ProductFactory {
    public static Product createProduct(String type) {
        switch (type) {
            case "Product1":
                return new ConcreteProduct1();
            case "Product2":
                return new ConcreteProduct2();
            case "Product3":
                return new ConcreteProduct3();
            default:
                throw new IllegalArgumentException("Unknown product type: " + type);
        }
    }
}