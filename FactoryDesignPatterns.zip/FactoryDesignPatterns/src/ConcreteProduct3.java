public class ConcreteProduct3 implements Product {
    @Override
    public void use() {
        System.out.println("Using ConcreteProduct3");
    }
} 