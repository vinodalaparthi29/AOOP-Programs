// Client: Demonstrates the use of the factory
public class Client {
    public static void main(String[] args) {
        // Create products using the factory
        Product product1 = ProductFactory.createProduct("Product1");
        Product product2 = ProductFactory.createProduct("Product2");
        Product product3 = ProductFactory.createProduct("Product3");

        // Use the products
        product1.use();
        product2.use();
        product3.use();
    }}
