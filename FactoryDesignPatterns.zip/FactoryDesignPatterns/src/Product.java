
public interface Product {
	void use();
}
