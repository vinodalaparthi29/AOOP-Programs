package com.CoustmerSupport;
import java.util.*;
public class TicketingSystem {
	private Queue<String> tq;
	public TicketingSystem() {
		tq=new LinkedList<>();
	}

}
