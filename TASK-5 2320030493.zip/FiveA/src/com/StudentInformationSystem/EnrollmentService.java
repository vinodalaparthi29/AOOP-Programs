package com.StudentInformationSystem;

public interface EnrollmentService {
	void enroll(Student stu,Courses course);

}
