package com.IspWorkerManagement;

public class Robot implements Worker{

	@Override
	public void work() {
		System.out.println("Robot is on work for his given tasks");
		
	}

}
