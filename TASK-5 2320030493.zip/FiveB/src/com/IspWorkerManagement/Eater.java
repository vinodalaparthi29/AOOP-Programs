package com.IspWorkerManagement;

public interface Eater {
	void Eat();

}
