package com.IspWorkerManagement;

public interface Worker {
	void work();

}
