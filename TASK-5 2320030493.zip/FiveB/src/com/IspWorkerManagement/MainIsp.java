package com.IspWorkerManagement;

public class MainIsp {
	public static void main(String[] args) {
		Robot robo=new Robot();
		Human human=new Human();
		robo.work();
		human.work();
		human.Eat();
	}

}
