package com.OcpShape;

public abstract class Shape {
	public abstract double calculateArea();

}
