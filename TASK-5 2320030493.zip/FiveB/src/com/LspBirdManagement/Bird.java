package com.LspBirdManagement;

public class Bird {
	
	public void fly() throws Exception {
		System.out.println("Bird can fly");
	}

}
