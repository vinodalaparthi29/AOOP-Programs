package com.LspBirdManagement;

public class MainLsp  {
	
	public static void main(String[] args)throws Exception {
		Bird parrot=new Bird();
		Bird ostrich=new Ostrich();
		parrot.fly();
		ostrich.fly();
	}

}
