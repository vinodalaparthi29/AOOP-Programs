package com.DipMessageprocessingSystem;

public interface MessageService {
	void sendMessage(String msg,String recipient);

}
