
public class MilkDecorator {

}
