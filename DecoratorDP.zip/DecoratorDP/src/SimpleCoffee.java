
public class SimpleCoffee {

}
