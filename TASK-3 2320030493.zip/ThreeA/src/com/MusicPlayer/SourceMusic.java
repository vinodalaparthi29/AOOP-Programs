package com.MusicPlayer;

public interface SourceMusic {
	void play();
	void stop();
	void pause();

}
