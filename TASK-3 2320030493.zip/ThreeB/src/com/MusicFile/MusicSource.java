package com.MusicFile;

public interface MusicSource {
	void play();
	void stop();
	String getMusicInfo();
}
