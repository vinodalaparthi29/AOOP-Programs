package com.musicstreaming;

class LocalFilePlayer implements MusicSource {

	@Override
	public void play(String song) {
		// TODO Auto-generated method stub
		System.out.println("Playing from local files: " + song);
	}
	
}
