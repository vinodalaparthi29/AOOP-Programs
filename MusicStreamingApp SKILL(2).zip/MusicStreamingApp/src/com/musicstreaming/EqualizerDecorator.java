package com.musicstreaming;

public class EqualizerDecorator implements MusicSource {
private MusicSource decoratedSource;
    
    public EqualizerDecorator(MusicSource source) {
        this.decoratedSource = source;
    }

	@Override
	public void play(String song) {
		// TODO Auto-generated method stub
		System.out.println("Applying equalizer settings...");
        decoratedSource.play(song);
	}
	
}
