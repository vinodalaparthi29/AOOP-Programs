package com.musicstreaming;

interface MusicSource {
	void play(String song);
}
