package com.musicstreaming;

class RadioStationPlayer implements MusicSource {

	@Override
	public void play(String song) {
		// TODO Auto-generated method stub
		System.out.println("Tuning into radio station for: " + song);
	}

}
