package com.musicstreaming;

public class MusicStreamingApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 MusicPlayerFacade player = new MusicPlayerFacade();
	        player.playLocal("Song A");
	        player.playOnline("Song B");
	        player.playRadio("Song C");
	        
	        // Using decorator to enhance playback
	        MusicSource enhancedLocalPlayer = new EqualizerDecorator(new LocalFilePlayer());
	        enhancedLocalPlayer.play("Song D");
	}

}
