package com.musicstreaming;

class MusicPlayerFacade {
	private MusicSource localPlayer;
    private MusicSource onlinePlayer;
    private MusicSource radioPlayer;
    
    public MusicPlayerFacade() {
        this.localPlayer = new LocalFilePlayer();
        this.onlinePlayer = new OnlineStreamingPlayer();
        this.radioPlayer = new RadioStationPlayer();
    }
    
    public void playLocal(String song) {
        localPlayer.play(song);
    }
    
    public void playOnline(String song) {
        onlinePlayer.play(song);
    }
    
    public void playRadio(String song) {
        radioPlayer.play(song);
    }
}
