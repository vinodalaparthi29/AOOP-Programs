package com.musicstreaming;

class OnlineStreamingPlayer implements MusicSource {

	@Override
	public void play(String song) {
		// TODO Auto-generated method stub
		System.out.println("Streaming online: " + song);
	}
}
